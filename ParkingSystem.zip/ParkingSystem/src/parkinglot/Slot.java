package parkinglot;

public class Slot {
	private String slotNumber;
	private boolean isParked;
	
	public boolean isItFree(){
		return isParked !=true;
		
	}

}
